package com.example.location;

import android.content.Intent;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
       // ImageView imageView3 = (ImageView) findViewById(R.id.imageView3);
//        EditText editText3 = findViewById(R.id.editText3);
//        EditText editText4 = (EditText) findViewById(R.id.editText4);
        ImageButton button5=findViewById(R.id.imageButton2);
        ImageButton button6=findViewById(R.id.imageButton3);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Main2Activity.this,"Capturing Garbage",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Main2Activity.this,MapsActivity.class);
                startActivityForResult(intent, 0);
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Main2Activity.this,"Directing to your Rewards Site",Toast.LENGTH_LONG).show();
            }
        });



    }
}
